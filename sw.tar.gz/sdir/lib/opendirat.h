#include <dirent.h>
DIR *opendirat (int, char const *, int, int *);
